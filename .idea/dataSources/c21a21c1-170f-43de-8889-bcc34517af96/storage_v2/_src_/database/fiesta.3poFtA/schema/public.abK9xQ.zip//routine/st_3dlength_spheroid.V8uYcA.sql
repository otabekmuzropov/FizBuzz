create function st_3dlength_spheroid(geometry, spheroid) returns double precision
    immutable
    strict
    language sql
as
$$
SELECT public._postgis_deprecate('ST_3DLength_Spheroid', 'ST_LengthSpheroid', '2.2.0');
    SELECT public.ST_LengthSpheroid($1,$2);
$$;

alter function st_3dlength_spheroid(geometry, spheroid) owner to postgres;

