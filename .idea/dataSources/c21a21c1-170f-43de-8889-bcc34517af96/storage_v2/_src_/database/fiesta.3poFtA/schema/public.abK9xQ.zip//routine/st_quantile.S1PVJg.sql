create function st_quantile(rastertable text, rastercolumn text, quantile double precision) returns double precision
    stable
    strict
    language sql
as
$$
SELECT ( public._ST_quantile($1, $2, 1, TRUE, 1, ARRAY[$3]::double precision[])).value
$$;

alter function st_quantile(text, text, double precision) owner to postgres;

