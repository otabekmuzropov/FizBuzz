create function st_approxsummarystats(rast raster, nband integer, sample_percent double precision) returns summarystats
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_summarystats($1, $2, TRUE, $3)
$$;

alter function st_approxsummarystats(raster, integer, double precision) owner to postgres;

