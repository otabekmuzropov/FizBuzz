create function st_geomcollfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE
	WHEN geometrytype(public.ST_GeomFromText($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN public.ST_GeomFromText($1,$2)
	ELSE NULL END

$$;

comment on function st_geomcollfromtext(text, integer) is 'args: WKT, srid - Makes a collection Geometry from collection WKT with the given SRID. If SRID is not given, it defaults to 0.';

alter function st_geomcollfromtext(text, integer) owner to postgres;

