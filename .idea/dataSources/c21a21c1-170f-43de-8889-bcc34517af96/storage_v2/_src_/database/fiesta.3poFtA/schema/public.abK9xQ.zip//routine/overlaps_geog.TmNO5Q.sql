create function overlaps_geog(geography, gidx) returns boolean
    immutable
    strict
    language sql
as
$$
SELECT $2 OPERATOR(public.&&) $1;
$$;

alter function overlaps_geog(geography, gidx) owner to postgres;

