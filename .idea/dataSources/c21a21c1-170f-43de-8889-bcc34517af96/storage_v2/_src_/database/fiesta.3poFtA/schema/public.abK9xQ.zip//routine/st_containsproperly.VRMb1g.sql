create function st_containsproperly(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.~) $2 AND public._ST_ContainsProperly($1,$2)
$$;

comment on function st_containsproperly(geometry, geometry) is 'args: geomA, geomB - Returns true if B intersects the interior of A but not the boundary (or exterior). A does not contain properly itself, but does contain itself.';

alter function st_containsproperly(geometry, geometry) owner to postgres;

